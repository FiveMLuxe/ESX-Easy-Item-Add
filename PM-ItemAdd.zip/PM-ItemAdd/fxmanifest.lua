fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author '_Project-RP'

client_scripts {
    "Client.lua"
}


server_scripts {
    "Server.lua",
   '@mysql-async/lib/MySQL.lua'
}

